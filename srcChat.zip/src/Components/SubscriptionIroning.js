const productIroning = [
  {
    title: " Ironing Subscription ",

    name: "Montly",
    type: "ironing",
    Price: 300,
    Qantity: 12,
    QantityLimted: "",
    Image: "/images/Card700.png",
  },
  {
    title: " Ironing Subscription ",
    name: "Year",
    type: "ironing",
    Price: 4000,
    Qantity: 16,
    QantityLimted: "",
    Image: "/images/Card4000.png",
  },
  {
    title: " Ironing Subscription ",
    name: "card",
    type: "ironing",
    Price: 300,
    Qantity: 50,
    QantityLimted: 13,
    Image: "/images/Card50.png",
  },
  {
    title: " Ironing Subscription ",
    name: "card",
    type: "ironing",
    Price: 480,
    Qantity: 100,
    QantityLimted: 25,
    Image: "/images/Card100.png",
  },
];
export default productIroning;
