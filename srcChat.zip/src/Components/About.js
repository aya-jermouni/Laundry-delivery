import React from 'react';
import './Style/ServicesPage.css';
import waterdroplet from './waterdroplet.js'; // Updated import path

function About() {
    const services = [
        { name: 'Clothes Cleaning', image: '/images/clothesService.jpg', link: '/service1' },
        { name: 'Clothes Ironing', image: '/images/ironningService.jpg', link: '/service2' },
        { name: 'Sneakers Cleaning', image: '/images/sneakersService.jpg', link: '/service3' },
    ];

    return (
        <div className="services-container">
            {services.map((service, index) => (
                <ServiceIcon
                    key={index}
                    imageSrc={service.image}
                    serviceName={service.name}
                    onClick={() => window.location.href = service.link}
                />
            ))}
        </div>
    );
}

export default About;
