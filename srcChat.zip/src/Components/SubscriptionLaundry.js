const productLaundry = [
  {
    title: " Laundry Subscription",

    name: "Montly",
    type: "Laundry",
    Price: 700,
    Qantity: 12,
    Image: "/images/CardL700.png",
    QantityLimted: "",
  },
  {
    title: " Laundry Subscription",
    name: "Year",
    type: "Laundry",
    Price: 7000,
    Qantity: 12,
    Image: "/images/Card7000.png",

    QantityLimted: "",
  },
  {
    title: " Laundry Subscription",
    name: "card",
    type: "Laundry",
    Price: 650,
    Qantity: 50,
    QantityLimted: 13,
    Image: "/images/Cardl50.png",
  },
  {
    title: " Laundry Subscription",
    name: "card",
    type: "Laundry",
    Price: 900,
    Qantity: 100,
    QantityLimted: 25,
    Image: "/images/Cardl100.png",
  },
];
export default productLaundry;
