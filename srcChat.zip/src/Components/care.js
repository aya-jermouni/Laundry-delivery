 const care =[
{
    description: "Skilled artisans provide expert care for various materials.",
    title:"Expert Craftsmanship",
    icon:"/images/shoemaker.png"
},
{
    description: "Advanced techniques restore and rejuvenate footwear.",
    title:"State-of-the-Art Cleaning",
    icon:"/images/plier.png"
},
{
    description: "Tailored care for leather, suede, canvas, and more.",
    title:"Customized Care",
    icon:"/images/shoe.png"
},
{
    description: " Extend the lifespan of your pairs with protective treatments.",
    title:"Protection and Conditioning:",
    icon:"/images/plier.png"
},
{
    description: " Experience hassle-free doorstep service.",
    title:"Convenient Pickup and Delivery:",
    icon:"/images/shoe.png"
}
]
export default care;